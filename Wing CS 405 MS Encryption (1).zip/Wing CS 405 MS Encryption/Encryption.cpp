// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// Encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Make sure the source and encryption key contain data
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // XOR each character with the corresponding character in the key.
    // Modulo allows the key to repeat when the source is longer than the key.
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    // Open the input file
    std::ifstream input_file(filename);

    // Make sure the file opened successfully
    if (!input_file)
    {
        std::cerr << "Unable to open file: " << filename << std::endl;
        return "";
    }

    // Read the entire file into a string
    std::stringstream buffer;
    buffer << input_file.rdbuf();

    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline
    size_t pos = string_data.find('\n');

    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    // Open the output file
    std::ofstream output_file(filename);

    if (!output_file)
    {
        std::cerr << "Unable to create file: " << filename << std::endl;
        return;
    }

    // Get the current date
    std::time_t current_time = std::time(nullptr);
    std::tm local_time{};

#ifdef _WIN32
    localtime_s(&local_time, &current_time);
#else
    localtime_r(&current_time, &local_time);
#endif

    // Save the file using the required format
    // Line 1: student name
    output_file << student_name << '\n';

    // Line 2: date in yyyy-mm-dd format
    output_file << std::put_time(&local_time, "%Y-%m-%d") << '\n';

    // Line 3: encryption key
    output_file << key << '\n';

    // Line 4+: encrypted or decrypted data
    output_file << data;
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";

    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // Stop if the input file could not be loaded
    if (source_string.empty())
    {
        return 1;
    }

    // Get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // Encrypt the original data
    const std::string encrypted_string =
        encrypt_decrypt(source_string, key);

    // Save the encrypted data
    save_data_file(
        encrypted_file_name,
        student_name,
        key,
        encrypted_string);

    // XOR the encrypted data with the same key to decrypt it
    const std::string decrypted_string =
        encrypt_decrypt(encrypted_string, key);

    // Save the decrypted data
    save_data_file(
        decrypted_file_name,
        student_name,
        key,
        decrypted_string);

    std::cout << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name
        << std::endl;

    return 0;
}