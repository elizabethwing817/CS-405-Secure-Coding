// NumericOverflows.cpp : This file contains the 'main' function.
// Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid

/// <summary>
/// Adds an increment to a starting value for a specified number of steps.
/// The function was changed to return a bool so the caller can determine
/// whether the calculation completed successfully.
/// The final numeric result is returned through the result reference parameter.
/// </summary>
template <typename T>
bool add_numbers(T const& start, T const& increment,
    unsigned long int const& steps, T& result)
{
    // Begin the calculation with the starting value supplied by the caller.
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for overflow BEFORE performing the addition.
        //
        // std::numeric_limits<T>::max() gives the largest value that
        // the current data type T can store.
        //
        // If result is already greater than:
        //
        //      maximum value - increment
        //
        // then adding increment would exceed the maximum value of T
        // and cause a numeric overflow.
        //
        // Returning false prevents the unsafe addition from occurring
        // and tells the calling function that the operation failed.
        if (increment > 0 &&
            result > std::numeric_limits<T>::max() - increment)
        {
            return false;
        }

        // The addition is safe because the overflow check passed.
        result += increment;
    }

    // Returning true tells the caller that all additions completed safely.
    return true;
}

/// <summary>
/// Subtracts a decrement from a starting value for a specified number of steps.
/// The function was changed to return a bool so the caller can determine
/// whether the calculation completed successfully.
/// The final numeric result is returned through the result reference parameter.
/// </summary>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement,
    unsigned long int const& steps, T& result)
{
    // Begin the calculation with the starting value supplied by the caller.
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for underflow BEFORE performing the subtraction.
        //
        // The values used by the provided test cases decrease toward zero.
        // If decrement becomes larger than the current result, subtracting
        // it would move the value below the valid lower boundary expected
        // by these tests.
        //
        // Returning false prevents the unsafe subtraction from occurring
        // and notifies the calling function that an underflow was detected.
        if (decrement > result)
        {
            return false;
        }

        // The subtraction is safe because the underflow check passed.
        result -= decrement;
    }

    // Returning true tells the caller that all subtractions completed safely.
    return true;
}


// NOTE:
// The unary '+' operator is used in front of some values when printing.
// This forces character-based data types such as char and unsigned char
// to be displayed as numeric values instead of characters.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    // how many times will we iterate
    const unsigned long int steps = 5;

    // how much will we add each step
    const T increment = std::numeric_limits<T>::max() / steps;

    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = "
        << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // result stores the numeric value produced by add_numbers().
    // success stores whether the addition completed without overflow.
    T result;

    std::cout << "\tAdding Numbers Without Overflow ("
        << +start << ", " << +increment << ", "
        << steps << ") = ";

    bool success = add_numbers<T>(
        start, increment, steps, result);

    // !success is used because the output is reporting overflow status.
    // A successful calculation means overflow is false.
    std::cout << "Overflow Status: "
        << std::boolalpha << !success
        << ", Result: " << +result << std::endl;


    std::cout << "\tAdding Numbers With Overflow ("
        << +start << ", " << +increment << ", "
        << (steps + 1) << ") = ";

    success = add_numbers<T>(
        start, increment, steps + 1, result);

    // If add_numbers() returns false, overflow was detected and prevented.
    std::cout << "Overflow Status: "
        << std::boolalpha << !success
        << ", Result: " << +result << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    // how many times will we iterate
    const unsigned long int steps = 5;

    // how much will we subtract each step
    const T decrement = std::numeric_limits<T>::max() / steps;

    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = "
        << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // result stores the numeric value produced by subtract_numbers().
    // success stores whether the subtraction completed without underflow.
    T result;

    std::cout << "\tSubtracting Numbers Without Overflow ("
        << +start << ", " << +decrement << ", "
        << steps << ") = ";

    bool success = subtract_numbers<T>(
        start, decrement, steps, result);

    // !success is used because the output is reporting underflow status.
    // A successful calculation means underflow is false.
    std::cout << "Underflow Status: "
        << std::boolalpha << !success
        << ", Result: " << +result << std::endl;


    std::cout << "\tSubtracting Numbers With Overflow ("
        << +start << ", " << +decrement << ", "
        << (steps + 1) << ") = ";

    success = subtract_numbers<T>(
        start, decrement, steps + 1, result);

    // If subtract_numbers() returns false, underflow was detected and prevented.
    std::cout << "Underflow Status: "
        << std::boolalpha << !success
        << ", Result: " << +result << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Run the same secure addition logic against multiple standard C++ types.
    // Because add_numbers() is a template, the same overflow protection can
    // be reused for signed integers, unsigned integers, and floating-point types.

    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Run the same secure subtraction logic against multiple standard C++ types.
    // Using a template allows the same underflow detection approach to be tested
    // with all of the data types required by the assignment.

    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    // Create a line of asterisks used to visually separate the test sections.
    const std::string star_line = std::string(50, '*');

    std::cout
        << "Starting Numeric Underflow / Overflow Tests!"
        << std::endl;

    // Run all overflow test cases.
    do_overflow_tests(star_line);

    // Run all underflow test cases.
    do_underflow_tests(star_line);

    std::cout << std::endl
        << "All Numeric Underflow / Overflow Tests Complete!"
        << std::endl;

    return 0;
}